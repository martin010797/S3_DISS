package Gui;

import OSPABA.Simulation;
//import Simulation.Simulator;

/*public interface ISimDelegate {
    void refresh(Simulation simulator);
}*/
