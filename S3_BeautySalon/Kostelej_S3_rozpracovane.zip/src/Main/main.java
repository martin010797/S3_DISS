package Main;

import Gui.BeautySalonGui;

public class main {
    public static void main(String[] args) {
        BeautySalonGui gui = new BeautySalonGui();
    }
}
