package simulation.Participants;

public class Hairstylist extends Personnel{
}
