package simulation.Participants;

public class MakeUpArtist extends Personnel{
}
