package simulation.Participants;

public enum CurrentPosition {
    ARRIVED,
    IN_QUEUE_FOR_ORDERING,
    ORDERING,
    IN_QUEUE_FOR_HAIRSTYLE,
    IN_QUEUE_FOR_MAKEUP,
    CLEANING_SKIN,
    MAKE_UP,
    HAIR_STYLING,
    IN_QUEUE_FOR_PAY,
    PAYING,
    PARKING
}
