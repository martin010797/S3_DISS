package simulation.Participants;

public class Receptionist extends Personnel{
}
