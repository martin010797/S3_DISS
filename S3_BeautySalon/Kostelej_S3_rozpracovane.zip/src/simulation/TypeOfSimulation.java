package simulation;

public enum TypeOfSimulation {
    OBSERVE,
    MAX_SPEED,
    MAX_WITH_CHART
}
